#!/usr/bin/env bash
# timemath — calendar-aware time arithmetic with leap-year support.
# Usage:
#   timemath [--local] [--hhmm] BASE [+|-] OFFSET
# BASE   : HH:MM | YYYY-MM-DD | YYYY-MM-DDTHH:MM
# OFFSET : +1d2h30m | -90m | +3h | -1d | etc. (any combo of d/h/m)
# Flags  : --local -> use local time (default UTC); --hhmm -> print HH:MM only.

set -euo pipefail

# Handle --help
if [[ "${1:-}" == "--help" ]]; then
  cat <<'EOF'
timemath — calendar-aware time arithmetic

Usage:
  timemath [--local] [--hhmm] BASE [+|-] OFFSET
  timemath [--local] [--hhmm] BASE OFFSET

Arguments:
  BASE:
    HH:MM                 Time of day (anchored to today's date)
    YYYY-MM-DD            Midnight at that date (T00:00)
    YYYY-MM-DDTHH:MM      ISO date-time
  OFFSET:
    Signed duration in minutes or mixed units:
      +N / -N (minutes)
      +[Nd][Nh][Nm] / -[Nd][Nh][Nm]  (any order, any subset)
    The sign may be separate: BASE + 2h30m

Options:
  --local   Use local timezone (DST-aware); default is UTC
  --hhmm    Output only HH:MM (modulo 24h)
  --help    Show this help

Examples:
  timemath 13:20 + 2h45m            → 2025-10-25T16:05
  timemath --hhmm 22:30 - 1h50m     → 20:40
  timemath 2024-02-28 + 2d          → 2024-03-01T00:00
  timemath --local 2025-10-25T07:15 - 1d2h30m

Notes:
  • Uses GNU date when available (leap years, months, DST).
  • Falls back to Python 3 datetime; otherwise to HH:MM-only math.
EOF
  exit 0
fi


use_local=0; hhmm_only=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --local) use_local=1; shift ;;
    --hhmm)  hhmm_only=1; shift ;;
    *) break ;;
  esac
done

if [[ $# -lt 2 ]]; then
  echo "Usage: timemath [--local] [--hhmm] BASE [+|-] OFFSET" >&2
  exit 2
fi

BASE="$1"; shift
# Allow either "±OFFSET" or "+|- OFFSET"
if [[ "$#" -ge 2 && ( "$1" == "+" || "$1" == "-" ) ]]; then
  sign="$1"; shift
  OFFSET="$sign$1"
else
  OFFSET="$1"
fi

# Normalize OFFSET like +1d2h30m into minutes
normalize_offset() {
  local s="$1"
  [[ "$s" =~ ^[+-] ]] || { echo "Offset must start with + or -: $s" >&2; exit 2; }
  local sign="${s:0:1}"; s="${s:1}"
  local d=0 h=0 m=0
  [[ "$s" =~ ([0-9]+)d ]] && d="${BASH_REMATCH[1]}"
  [[ "$s" =~ ([0-9]+)h ]] && h="${BASH_REMATCH[1]}"
  [[ "$s" =~ ([0-9]+)m ]] && m="${BASH_REMATCH[1]}"
  # If it's pure minutes like 90, catch that:
  [[ "$s" =~ ^[0-9]+$ ]] && m="$s"
  local total=$(( d*1440 + h*60 + m ))
  [[ "$sign" == "-" ]] && total=$((-total))
  echo "$total"
}

offset_min="$(normalize_offset "$OFFSET")"

is_hhmm()        { [[ "$1" =~ ^([01]?[0-9]|2[0-3]):[0-5][0-9]$ ]]; }
is_date()        { [[ "$1" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; }
is_datetime()    { [[ "$1" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T([01]?[0-9]|2[0-3]):[0-5][0-9]$ ]]; }

print_out() {
  local epoch="$1"
  if (( hhmm_only )); then
    if (( use_local )); then date -d "@$epoch" +%H:%M; else TZ=UTC date -u -d "@$epoch" +%H:%M; fi
  else
    if (( use_local )); then date -d "@$epoch" +%Y-%m-%dT%H:%M; else TZ=UTC date -u -d "@$epoch" +%Y-%m-%dT%H:%M; fi
  fi
}

gnu_date_ok=0
if date --version >/dev/null 2>&1; then gnu_date_ok=1; fi

if (( gnu_date_ok )); then
  # GNU date path (calendar-correct)
  if is_hhmm "$BASE"; then
    # anchor to today
    if (( use_local )); then
      base_epoch="$(date -d "$(date +%Y-%m-%d)T$BASE" +%s)"
      result_epoch=$(( base_epoch + offset_min*60 ))
      print_out "$result_epoch"
    else
      base_epoch="$(TZ=UTC date -u -d "$(TZ=UTC date -u +%Y-%m-%d)T$BASE" +%s)"
      result_epoch=$(( base_epoch + offset_min*60 ))
      print_out "$result_epoch"
    fi
  elif is_date "$BASE"; then
    if (( use_local )); then base_epoch="$(date -d "${BASE}T00:00" +%s)"
    else base_epoch="$(TZ=UTC date -u -d "$BASET00:00" +%s)"; fi
    result_epoch=$(( base_epoch + offset_min*60 ))
    print_out "$result_epoch"
  elif is_datetime "$BASE"; then
    if (( use_local )); then base_epoch="$(date -d "$BASE" +%s)"
    else base_epoch="$(TZ=UTC date -u -d "$BASE" +%s)"; fi
    result_epoch=$(( base_epoch + offset_min*60 ))
    print_out "$result_epoch"
  else
    echo "Unrecognized BASE: use HH:MM, YYYY-MM-DD, or YYYY-MM-DDTHH:MM" >&2
    exit 2
  fi
  exit 0
fi

# Python fallback (calendar-correct)
if command -v python3 >/dev/null 2>&1; then
python3 - "$BASE" "$offset_min" "$use_local" "$hhmm_only" <<'PY'
import sys, re, os, datetime, time
base, off_min, use_local, hhmm_only = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])

def parse_base(s):
    if re.match(r'^\d{2}:\d{2}$', s):
        today = datetime.date.today()
        h,m = map(int, s.split(':'))
        dt = datetime.datetime(today.year, today.month, today.day, h, m)
    elif re.match(r'^\d{4}-\d{2}-\d{2}$', s):
        y,m,d = map(int, s.split('-'))
        dt = datetime.datetime(y,m,d,0,0)
    elif re.match(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$', s):
        date_part, time_part = s.split('T')
        y,m,d = map(int, date_part.split('-'))
        hh,mm = map(int, time_part.split(':'))
        dt = datetime.datetime(y,m,d,hh,mm)
    else:
        raise SystemExit("Unrecognized BASE")
    return dt

dt = parse_base(base)
if not use_local:
    # treat dt as UTC-naive; print as UTC-naive
    result = dt + datetime.timedelta(minutes=off_min)
    out = result.strftime('%Y-%m-%dT%H:%M')
    if hhmm_only: out = result.strftime('%H:%M')
else:
    # local time semantics
    result = dt + datetime.timedelta(minutes=off_min)
    out = result.strftime('%Y-%m-%dT%H:%M')
    if hhmm_only: out = result.strftime('%H:%M')
print(out)
PY
exit $?
fi

# Minimal fallback: HH:MM only (no calendar, no leap/DST)
if is_hhmm "$BASE"; then
  IFS=: read -r H M <<<"$BASE"
  total=$(( H*60 + M + offset_min ))
  (( total %= 1440, total < 0 )) && total=$(( total + 1440 ))
  printf '%02d:%02d\n' $(( total/60 )) $(( total%60 ))
  exit 0
fi

echo "Neither GNU date nor Python3 available; and BASE requires calendar math." >&2
exit 2

